
//Creacion de la "base de datos"
let listaProducto=[
    {id:0,nombre:"Asesoria normal",valor:14990,cupo:20},
    {id:1,nombre:"Asesoria Personalizada",valor:20000,cupo:10},
    {id:2,nombre:"Asesoria VIP",valor:39900,cupo:7},

];



//funciones para ir por paginas
function irLogin(){
    location.href ="html/login.html";
};

function irLoginAdmin(){
    location.href ="login.html";
};


//CRUD (ADMIN)

function actualizarTabla(){
    let tabla = document.querySelector(".listaProductos");
    // limpiar tabla
    while(tabla.rows.length > 1){
        tabla.deleteRow(1);
    }
    // agregar los productos a la tabla
    for (let producto of listaProducto){
        let fila = document.createElement("tr");
        fila.innerHTML = `<td>${producto.id}</td><td>${producto.nombre}</td><td>${producto.valor}</td><td>${producto.cupo}</td>`;
        tabla.appendChild(fila);
    }
}













function agregarProducto(){
    let id = document.getElementById("idProducto").value;
    let nombre = document.getElementById("nombreProducto").value;
    let valor = document.getElementById("valorProducto").value;
    let cantidad = document.getElementById("cantidadProducto").value;

    listaProducto.push({id,nombre,valor,cantidad});
    actualizarTabla();
}

function eliminarProducto(){
    
}

function editarProducto(){
}

actualizarTabla()














