document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (username === 'admin' && password === 'admin') {
        window.location.href = 'crud.html';
    } else {
        document.getElementById('error').innerText = 'Usuario o contraseña incorrectos';
    }
});

if (document.getElementById('logoutButton')) {
    document.getElementById('logoutButton').addEventListener('click', function() {
        window.location.href = 'index.html';
    });
}